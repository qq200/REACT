import React, {Component} from 'react'
import {Dropdown, Image} from 'react-bootstrap'
import rating from 'react-rating'
import Rating from 'react-rating';

class Product extends Component{
    constructor(props){
        super(props);

        this.state={
           data: props.data,
           mode:props.mode //regimul de afisare
           //vo exista moduri : compact, preview, full
        }
    }


    render(){
        let data=this.state.data;
        let mode=this.state.mode;
        let dom=<div className="Product">
                <img src={data.photo}/>
                <h2>{data.name}</h2>
                <p>{data.price.amount}</p>
                <Rating/>
                </div>
        switch(mode){
            case "compact": 
            dom=<div className="Product">
                <img src={data.photo} width="100"/>
                <h2>{data.name}</h2>
                <p>{data.price.amount}</p>
                <Rating/>
                </div>;
            break;
            case "preview":
            dom=<div className="Product">
                <img src={data.photo} width="300"/>
                <h2>{data.name}</h2>
                <p>{data.price.amount}</p>
                <Rating/>
                </div>;
            break;
            case "full": break;
            case "admin":
            dom=<div className="Product row">
                 <div className="col-1">
                <Image src={data.photo} fluid />
                </div>
                <h2 class="col-7">{data.name}</h2>
                <p class="col-2">{data.price.amount}</p>
                <Dropdown class="col-2">
                <Dropdown.Toggle variant="primary" id="dropdown-basic">
                    Actions
                </Dropdown.Toggle>

                <Dropdown.Menu>
                    <Dropdown.Item href="#/action-1">View</Dropdown.Item>
                    <Dropdown.Item href="#/action-2">Edit</Dropdown.Item>
                    <Dropdown.Item href="#/action-3">Remove</Dropdown.Item>
                    <Dropdown.Item href="#/action-4">Publish</Dropdown.Item>
                </Dropdown.Menu>
                </Dropdown>
                <Rating />
                                </div>;
            break;
            
        }

        return dom;
    }
}

export default Product;
// ACASA de optimizat JSX din switch