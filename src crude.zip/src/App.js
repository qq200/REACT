import React from 'react';
import {BrowserRouter as Router, Link, Route} from 'react-router-dom'
import ProductForm from './products/ProductForm'
import ProductList from './products/ProductList'
import Product from './products/Product'

import {Button, Navbar} from 'react-bootstrap'
function App() {
  return (
    <div className="App">

    {/* <Product data={{photo: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlORIsX6ONEY_R6OnNxJsID-tXqDqxbKpW5Oz0Cwm52pHg0z2F",
                    name: "aiFoone xxl",
                    price:{
                        amount: 100,
                        currency: "USD"
                    },
                    rating: 4.5,
                    promo:true
    }}
    
    mode="admin"/> */}

      <Router>
          
          <Route path="/product/add" component={ProductForm}/>

          <Route path="/products" exact component={ProductList}/>
          {/* <Route path="/product/details" exact component={Product}/> */}


            <Navbar className="container mb-5" fixed="bottom">
            <Link to="/products" className="mr-auto" >
              <Button variant="secondary" size="lg" className="rounded-pill shadow">Products</Button>
            
            </Link>
            {/* <Link to="/product/details" className="mr-auto" >
              <Button variant="secondary" size="lg" className="rounded-pill shadow">Details</Button>
            
            </Link> */}
            <Link to="/product/add" className="ml-auto">
              <Button variant="primary" size="lg" className="rounded-pill shadow">+</Button>
            
            </Link>
            
            </Navbar>
      </Router> 
    </div>
  );
}

export default App;
