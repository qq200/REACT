import React, {Component} from 'react'
import {Table} from 'react-bootstrap'


class ProductList extends Component{


//////////////de refacur in ciclu in <td> (promo---de evidentiat alta class Name)
 ///////////////////+class Product -->new Product
 ////////////+npm- >faker->generate products


getProducts(){
    return[
        {
            photo: "./images/p1.jpg",
            name: "aiFoone xxl",
            price:{
                amount: 100,
                currency: "USD"
            },
            rating: 4.5,
            promo:true
        }
    ]



 }



    render(){
        return(
            <div className="container">
                <Table striped bordered hover>
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Photo</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Rating</th>
                    </tr>
                </thead>
                <tbody>
                    <tr className="text-success">
                    <td>1</td>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                    </tr>
                    <tr>
                    <td>2</td>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                    </tr>
                    <tr>
                    <td>3</td>
                    <td colSpan="2">Larry the Bird</td>
                    <td>@twitter</td>
                    </tr>
                </tbody>
                </Table>
            </div>
        )
}
}


export default ProductList;