import React, {Component} from 'react'
import {Form, FormGroup, Button} from 'react-bootstrap'

class ProductForm extends Component{
    constructor(){
        super()
        this.state={
            validated: false

        }
    }
    handleSubmit(event){
        event.preventDefault(); ///nu permite sa faca refresh
        alert();
    }
    render(){
        return(
            <div id="product-form">
                <Form onSubmit={e => this.handleSubmit(e)} className="container mt-5">
                    <Form.Group>
                        <Form.Control type="text" placeholder="product name" size="lg"/> 
                    </Form.Group>
                    <Form.Group>
                        <Form.Control type="text" placeholder="product name" size="lg"/> 
                    </Form.Group>
                    <Form.Group>
                        <Form.Control type="text" placeholder="product name" size="lg"/> 
                    </Form.Group>
                    <Form.Group>
                        <Form.Control type="text" placeholder="product name" size="lg"/> 
                    </Form.Group>
                    <Form.Group>
                        <Form.Control type="text" placeholder="product name" size="lg"/> 
                    </Form.Group>
                    <Button className="lg " type="submit">Submit</Button>
                </Form>
            </div>

        )
    }    
}
export default ProductForm;