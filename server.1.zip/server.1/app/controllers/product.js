const fs=require('fs');
exports.productIndex=(req, res)=>{
    fs.readFile('./database/products.json', (err, data)=>{// callback legate de date obtin sau eroare sau date
        if(!err){
            // console.log(data.toString());
            res.append('Content-Type', 'application/json')
            res.send(data.toString())
        }else{
			console.log(err);
		}
       

    });
}
exports.productDetails=(req, res)=>{
    console.log(req.params.productid) //returneaza un produs
    fs.readFile('./database/products.json', (err, data)=>{// callback legate de date obtin sau eroare sau date
        if(!err){
        let products=JSON.parse(data)
        let product=products.find(p=>p.id==req.params.productid)
            console.log(products.find(p=>p.id==req.params.productid));
            // res.append('Content-Type', 'application/json')
            // // res.send(data.toString())
            // res.send(product)
            res.jsonp(product)
        }else{

			console.log(err);
		}
       

    });
}
exports.productDelete=(req, res)=>{
    console.log(req.params.productid) //sterege
    fs.readFile('./database/products.json', (err, data)=>{// callback legate de date obtin sau eroare sau date
        if(!err){
        let products=JSON.parse(data)
        let product=products.find(p=>p.id==req.params.productid)
            console.log(products.find(p=>p.id==req.params.productid));
            // res.append('Content-Type', 'application/json')
            // // res.send(data.toString())
            // res.send(product)
            res.jsonp(product)
        }else{

			console.log(err);
		}
       

    });
}