const home = require('../app/controllers/home');
const product = require('../app/controllers/product');

//you can include all your controllers

module.exports = function (app, passport) {

    app.get('/', home.home);//home
   
//product routing
    app.get('/products', product.productIndex);
    app.get('/products/:productid', product.productDetails)
    app.delete('/products/:productid', product.productDelete)
 
}
