const express = require('express')
const app = express()
const port = 3000
const fs=require('fs')


//routing
// app.get('/', (req, res) => res.send('Hello World!'))

//################CONTROLERS################
const productIndex=(req, res)=>{
    fs.readFile('./database/products.json', (err, data)=>{// callback legate de date obtin sau eroare sau date
        if(!err){
            // console.log(data.toString());
            res.append('Content-Type', 'application/json')
            res.send(data.toString())
        }
        // console.log(err);
       

    });
}
const productDetails=(req, res)=>{
    console.log(req.params.productid) //returneaza un produs
    fs.readFile('./database/products.json', (err, data)=>{// callback legate de date obtin sau eroare sau date
        if(!err){
        let products=JSON.parse(data)
        let product=products.find(p=>p.id==req.params.productid)
            console.log(products.find(p=>p.id==req.params.productid));
            // res.append('Content-Type', 'application/json')
            // // res.send(data.toString())
            // res.send(product)
            res.jsonp(product)
        }
        // console.log(err);
       

    });
}
const productDelete=(req, res)=>{
    console.log(req.params.productid) //sterege
    fs.readFile('./database/products.json', (err, data)=>{// callback legate de date obtin sau eroare sau date
        if(!err){
        let products=JSON.parse(data)
        let product=products.find(p=>p.id==req.params.productid)
            console.log(products.find(p=>p.id==req.params.productid));
            // res.append('Content-Type', 'application/json')
            // // res.send(data.toString())
            // res.send(product)
            res.jsonp(product)
        }
        // console.log(err);
       

    });
}
//RESTFUL routing/ RESURS routing  ???? de citit, list of mimetypes??, uuid??, => ?, postman ? de sters failul delete?

app.get('/products', productIndex)
app.get('/products/:productid', productDetails)
app.delete('/products/:productid', productDelete)
app.listen(port, () => console.log(`server started on ${port}!`))