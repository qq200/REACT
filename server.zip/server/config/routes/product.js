
const product = require('../../app/controllers/product');
const {check } = require('express-validator');

//you can include all your controllers

module.exports = function (app) {

  //product routing
    app.get('/products', product.productIndex);
    app.get('/products/create', product.productCreate)
    app.post('/products/save', product.productSave)


    app.post('/products/save',[
      check('name').isLength({ min: 3 }),
      check('price.amount').isLength({ min: 1 })
    ],
     product.productSave)


    app.delete('/products/:productid', product.productDelete)
    app.get('/products/:productid', product.productDetails)
 
}
// acasa reguli de validare :https://express-validator.github.io/docs/
// in class Product  (object)-> cod care va lua toate proprietatile prin destructurizare si le pune in this.