
const product = require('../../app/controllers/product');

//you can include all your controllers

module.exports = function (app) {

  //product routing
    app.get('/products', product.productIndex);
    app.get('/products/:productid', product.productDetails)
    app.delete('/products/:productid', product.productDelete)
 
}
