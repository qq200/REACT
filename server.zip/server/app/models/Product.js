const fs=require('fs')

class Product{
     constructor({name, photo, price, rating, promo}){
        console.log(">>",name, photo, price, rating, promo)
        this.name=name
        this.photo=photo
        this.price=price
        this.rating=rating
        this.promo=promo
    }

    save(){
        let data=fs.readFileSync("./database/products.json")
        let product_json=JSON.parse(data)
        product_json.push(this)
        data=JSON.stringify(product_json, null, 2) // taie din date ce e in plus de constructor
            fs.writeFileSync("./database/products.json", data)
        // console.log(product_json)
    }
}

module.exports=Product